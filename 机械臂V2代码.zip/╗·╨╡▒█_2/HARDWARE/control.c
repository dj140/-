#include "control.h"
#include "sys.h"


int sub1,sub2,sub3,sub4,temp1,temp2,temp3,temp4;
u8 flag=0,i=0;
void control(void)
{
		sub1=Get_Adc_Average(0,5);
		sub2=Get_Adc_Average(1,5);
		sub3=Get_Adc_Average(2,5);
		sub4=Get_Adc_Average(3,5);
	
	  //AD_value  = 3300000/4096*sub[5]/1000;
		// 0-4095 
		// 6300 - 7020
	  AD1_value  = 6300+0.1758*sub1;
		//printf("AD1 value = %d   \r\n", AD1_value);
		AD2_value  = 7020-0.1758*sub2;
		AD3_value  = 6300+0.1758*sub3;
		AD4_value  = 7020-0.1758*sub4;


		if(key_scan()==1)flag++;	
		if(flag==1)
		{
			count++;
			if(count==1)printf("��ʼ������λ�� \r\n");
			//���ADCֵ����һ�β�ͬ�����¼��ֵ
			a=temp1-AD1_value;
			b=temp2-AD2_value;
			c=temp3-AD3_value;
			if(a>10||a<-10)
			{
				if(a<20||a>-20)
			{
				data[d][0]=1;				
				printf("AD1 value = %d   \r\n", AD1_value);
				//��¼�������			
				data[d][1]=AD1_value;	
				TIM_SetCompare2(TIM3,AD1_value);
				d++;
			}
			}
			if(b>10||b<-10)
			{
				if(b<20||b>-20)
				{
					data[d][0]=2;				
					printf("AD2 value = %d   \r\n", AD2_value);		
					data[d][1]=AD2_value;
					TIM_SetCompare3(TIM3,AD2_value);
					d++;
				}
			}
			if(c>10||c<-10)
			{
				if(c<20||c>-20)
				{
					data[d][0]=3;				
					printf("AD3 value = %d   \r\n", AD3_value);		
					data[d][1]=AD3_value;
					TIM_SetCompare4(TIM3,AD3_value);
					d++;
				}
			}

			 if(d==1000)
			{
				d=0;
				printf("����ռ����� \r\n");
			}	
				
		}
		if(flag==2)
		{
      printf("�������� \r\n");
			flag=3;
			count=0;
		}
		
		if(flag==4)
		{
			printf("��ʼ�ط� \r\n");
			for(i=0;i<d;i++)
			{	
				//�ж϶���˶�˳��
				if(data[i][0]==1)
				{
					TIM_SetCompare2(TIM3,data[i][1]);
				}
				if(data[i][0]==2)
				{
					TIM_SetCompare3(TIM3,data[i][1]);
					
				}
				if(data[i][0]==3)
				{
					TIM_SetCompare4(TIM3,data[i][1]);
				}
				printf("data= %d   \r\n", data[i][0]);
				printf("data= %d   \r\n", data[i][1]);
				delay_ms(100);
			}	
			d=0;flag=0;
		}
		if(flag!=1&&rev_flag==0)
		{
			if(temp1-AD1_value>5||temp1-AD1_value<-5)
			{
					if(temp1-AD1_value<100&&temp1-AD1_value>-100)
				{
					if(AD2_value>6850)AD2_value=6850;//���޷�
					if(AD2_value<6475)AD2_value=6475;
					printf("AD1 value = %d   \r\n", AD1_value);
					TIM_SetCompare2(TIM3,AD1_value);
				}
			}		
						
			if(temp2-AD2_value>5||temp2-AD2_value<-5)
			{
					if(temp2-AD2_value<100&&temp2-AD2_value>-100)
				{
					if(AD2_value>6850)AD2_value=6850;
					if(AD2_value<6450)AD2_value=6450;
					printf("AD2 value = %d   \r\n", AD2_value);
					TIM_SetCompare3(TIM3,AD2_value);
				}  
			}		
			
			if(temp3-AD3_value>10||temp3-AD3_value<-10)
			{
					if(temp3-AD3_value<100&&temp3-AD3_value>-100)
				{
					if(AD3_value>6950)AD3_value=6950;
					if(AD3_value<6780)AD3_value=6780;
					printf("AD3 value = %d   \r\n", AD3_value);
					TIM_SetCompare4(TIM3,AD3_value);
				}
			}
			
			if(temp4-AD4_value>10||temp4-AD4_value<-10)
			{
					//6350,6700
					//
		      if(AD4_value>6400)AD4_value=6700;
					if(AD4_value<6400)AD4_value=6400;
					printf("AD4 value = %d   \r\n", AD4_value);
					TIM_SetCompare1(TIM3,AD4_value);				
				
			}
		}
	
		//������һ��ADֵ
		temp1=AD1_value;
		temp2=AD2_value;
		temp3=AD3_value;
		temp4=AD4_value;
}
